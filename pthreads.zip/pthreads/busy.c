#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h> 

int thread_count,N=100000000;
double sum = 0.0;
int flag = 0;

void* busyWait(void *rank);

int main(int argc, char * argv[]){
	if(argc !=2){
		printf("Debe ejecutar el programa con los siguientes valores en orden:\n");
		printf("[numero de hilos]\n");
		return 0;
	}

	clock_t start, end; 

	thread_count = strtol(argv[1],NULL,10);

	long thread;
	pthread_t* thread_handles;
	thread_handles = malloc(thread_count*sizeof(pthread_t));

	for(thread = 0; thread < thread_count; thread++)
		pthread_create(&thread_handles[thread],NULL,busyWait,(void*)thread);

	start = clock(); 

	for(thread = 0; thread < thread_count; thread++)
		pthread_join(thread_handles[thread],NULL);//*

	free(thread_handles); 

	sum = sum*4;
	end = clock();
	//printf("%f\n", sum);

	printf("The time was: %f\n", ((double)end - start) / CLOCKS_PER_SEC); 

	return 0;

}

void* busyWait(void *rank){
	long my_rank = (long)rank;
	double factor;
	long long i;
	long long my_n = N/thread_count;
	long long my_first_i = my_n * my_rank;
	long long my_last_i = my_first_i + my_n;

	if(my_first_i % 2 == 0)
		factor = 1.0;
	else
		factor = -1.0;

	for(i=my_first_i; i<my_last_i;i++,factor=-factor){
		while(flag!=my_rank);
		sum += factor/(2*i+1);
		flag = (flag+1) % thread_count;
		//printf("%d\n",flag );
	}

	printf("Termino en el hilo %ld\n",my_rank );
	return NULL;
}