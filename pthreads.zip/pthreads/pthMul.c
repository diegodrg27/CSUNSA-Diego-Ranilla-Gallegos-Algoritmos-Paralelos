#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define lim 4

int thread_count,M,N;
int **A, *X,*y;

void* multiplicacion(void *rank);
void showMatrix();
void showAnswer();

int main(int argc, char * argv[]){
	if(argc !=4){
		printf("Debe ejecutar el programa con los siguientes valores en orden:\n");
		printf("[numero de hilos] [dimension M] [dimension N]\n");
		return 0;
	}

	thread_count = strtol(argv[1],NULL,10);
	M = strtol(argv[2],NULL,10);
	N = strtol(argv[3],NULL,10);

	//Generar MATRIZ A
	A = (int **)malloc(M*sizeof(int*));

	int i,j;
	for( i=0; i<M ; i++){
		A[i] = (int*)malloc(N*sizeof(int));
	}

	for( i=0 ; i<M ; i++){
		for( j=0;j<N ; j++){
			A[i][j]= rand()%(lim+1);
		}
	}
	
	//GENERAR VECTOR X
	X = (int *)malloc(N*sizeof(int));

	for(i=0;i<N;i++)
		X[i] = rand()%(lim+1);

	//GENERAR VECTOR Y
	y = (int *)malloc(M*sizeof(int));


	//showMatrix();
	//GENERAR THREADS
	long thread;
	pthread_t* thread_handles;
	thread_handles = malloc(thread_count*sizeof(pthread_t));

	clock_t start, end; 

	start = clock(); 

	for(thread = 0; thread < thread_count; thread++)
		pthread_create(&thread_handles[thread],NULL,multiplicacion,(void*)thread);

	for(thread = 0; thread < thread_count; thread++)
		pthread_join(thread_handles[thread],NULL);//*

	free(thread_handles);
	end = clock();
	printf("The time was: %f\n", ((double)end - start) / CLOCKS_PER_SEC); 
	//showAnswer();
	free(X);
	free(y);

	for(i=0;i<M;i++){
		free(A[i]);
	}
	free(A);
	return 0;
}


void* multiplicacion(void *rank){
	long my_rank = (long)rank;
	int i,j;
	int local_m = M/thread_count;

	int first_row = my_rank*local_m;
	int last_row = (my_rank+1)*local_m -1;

	for(i=first_row;i<=last_row;i++){
		y[i] = 0.0;
		for (j = 0; j < N; j++)
		{
			y[i] +=A[i][j]*X[j]; 
		}
	}
	return NULL;

}

void showMatrix(){
	int i,j;
	for(i=0;i<M;i++){
		for (j=0;j<N;j++){
			printf("%d ", A[i][j]);
		}
		printf("\n");
	}

	printf("\n");
	for(i=0;i<N;i++){
		printf("%d ", X[i]);
	}
	printf("\n");
}

void showAnswer(){
	int i;
	for(i=0;i<M;i++){
		printf("%d ", y[i]);
	}
	printf("\n");
}